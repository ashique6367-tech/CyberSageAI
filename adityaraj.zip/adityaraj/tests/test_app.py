"""
Unit and Integration Tests for CyberSage AI
Tests deterministic URL analysis, text NLP heuristics, image validation,
scoring and correlation, demo provider behavior, and API contracts.
Can be executed with either `pytest` or Python's standard `unittest`.
"""

import sys
import unittest
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from app import (
    analyze_message_text,
    analyze_security_logs,
    analyze_static_url,
    correlate_and_score,
    deduplicate_findings,
    extract_urls_from_text,
    validate_image_upload,
    DemoGemma4Provider,
    Finding,
)


class TestStaticUrlAnalysis(unittest.TestCase):
    """Tests for static URL security analysis without network requests."""

    def test_benign_url(self):
        findings = analyze_static_url("https://www.google.com/search?q=cybersecurity")
        # Standard HTTPS known domain should have 0 high/critical findings
        high_crit = [f for f in findings if f.severity in ["high", "critical"]]
        self.assertEqual(len(high_crit), 0)

    def test_ip_address_host(self):
        findings = analyze_static_url("http://192.168.1.100/login.php")
        ip_findings = [f for f in findings if "IP Address Host" in f.title]
        self.assertTrue(len(ip_findings) > 0)
        self.assertEqual(ip_findings[0].severity, "high")
        self.assertEqual(ip_findings[0].source_type, "deterministic_check")

    def test_punycode_homograph(self):
        findings = analyze_static_url("https://xn--pple-43d.com/login")
        puny_findings = [f for f in findings if "Punycode" in f.title]
        self.assertTrue(len(puny_findings) > 0)
        self.assertEqual(puny_findings[0].severity, "high")

    def test_userinfo_confusion(self):
        findings = analyze_static_url("http://paypal.com:verify@attacker-domain.com/secure")
        userinfo_findings = [f for f in findings if "User-Info" in f.title]
        self.assertTrue(len(userinfo_findings) > 0)
        self.assertEqual(userinfo_findings[0].severity, "high")

    def test_non_https_scheme(self):
        findings = analyze_static_url("http://example.com")
        http_findings = [f for f in findings if "Unencrypted Transport" in f.title]
        self.assertTrue(len(http_findings) > 0)

    def test_url_shortener(self):
        findings = analyze_static_url("https://bit.ly/3xSuspiciousLink")
        shortener_findings = [f for f in findings if "Shortening Service" in f.title]
        self.assertTrue(len(shortener_findings) > 0)
        self.assertEqual(shortener_findings[0].severity, "medium")

    def test_brand_impersonation(self):
        findings = analyze_static_url("https://paypal-account-verification-portal.com/login")
        brand_findings = [f for f in findings if "Brand Impersonation" in f.title]
        self.assertTrue(len(brand_findings) > 0)
        self.assertEqual(brand_findings[0].severity, "high")

    def test_long_url(self):
        long_url = "https://example.com/" + "a" * 160
        findings = analyze_static_url(long_url)
        long_findings = [f for f in findings if "Abnormally Long URL" in f.title]
        self.assertTrue(len(long_findings) > 0)

    def test_empty_url(self):
        findings = analyze_static_url("")
        self.assertEqual(len(findings), 0)


class TestMessageTextAnalysis(unittest.TestCase):
    """Tests for message and email text heuristics and extraction."""

    def test_urgent_coercive_language(self):
        text = "URGENT: Your account has been suspended! Immediate action required within 24 hours."
        findings, urls = analyze_message_text(text)
        urgency_findings = [f for f in findings if "Urgency" in f.title]
        self.assertTrue(len(urgency_findings) > 0)
        self.assertEqual(urgency_findings[0].severity, "high")

    def test_credential_solicitation(self):
        text = "Please reply with your one-time code (OTP) and current password to restore access."
        findings, urls = analyze_message_text(text)
        cred_findings = [f for f in findings if "Credentials" in f.title or "password" in f.title.lower()]
        self.assertTrue(len(cred_findings) > 0)
        self.assertEqual(cred_findings[0].severity, "critical")

    def test_security_bypass_instructions(self):
        text = "Download the attached invoice and disable antivirus warning to run the macro."
        findings, urls = analyze_message_text(text)
        bypass_findings = [f for f in findings if "Circumvent" in f.title or "disable" in f.title.lower()]
        self.assertTrue(len(bypass_findings) > 0)
        self.assertEqual(bypass_findings[0].severity, "critical")

    def test_benign_text_no_false_findings(self):
        text = "Hi Sarah, can you review the attached project schedule for our sprint planning on Friday? Thanks!"
        findings, urls = analyze_message_text(text)
        self.assertEqual(len(findings), 0)

    def test_extract_embedded_urls(self):
        text = "Visit https://secure-bank.example.com/update and http://192.168.1.1/test for details."
        urls = extract_urls_from_text(text)
        self.assertIn("https://secure-bank.example.com/update", urls)
        self.assertIn("http://192.168.1.1/test", urls)


class TestLogAnalysis(unittest.TestCase):
    """Tests for security log pattern identification."""

    def test_brute_force_detection(self):
        logs = """
        auth: Failed password for user root from 10.0.0.1
        auth: Failed password for user root from 10.0.0.1
        auth: Failed password for user root from 10.0.0.1
        auth: Failed password for user admin from 10.0.0.1
        """
        findings = analyze_security_logs(logs)
        bf_findings = [f for f in findings if "Brute-Force" in f.title]
        self.assertTrue(len(bf_findings) > 0)

    def test_web_attack_patterns(self):
        logs = "GET /search?id=1' UNION SELECT null,password FROM users-- 200"
        findings = analyze_security_logs(logs)
        sqli_findings = [f for f in findings if "SQL Injection" in f.title]
        self.assertTrue(len(sqli_findings) > 0)
        self.assertEqual(sqli_findings[0].severity, "critical")


class TestImageValidation(unittest.TestCase):
    """Tests for screenshot upload safety and format inspection."""

    def test_valid_png(self):
        # PNG magic bytes
        png_bytes = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR" + b"\x00" * 32
        is_valid, mime, err = validate_image_upload(png_bytes, "screen.png")
        self.assertTrue(is_valid)
        self.assertEqual(mime, "image/png")

    def test_valid_jpeg(self):
        jpeg_bytes = b"\xff\xd8\xff\xe0\x00\x10JFIF" + b"\x00" * 32
        is_valid, mime, err = validate_image_upload(jpeg_bytes, "screen.jpg")
        self.assertTrue(is_valid)
        self.assertEqual(mime, "image/jpeg")

    def test_valid_webp(self):
        webp_bytes = b"RIFF\x20\x00\x00\x00WEBPVP8 " + b"\x00" * 32
        is_valid, mime, err = validate_image_upload(webp_bytes, "screen.webp")
        self.assertTrue(is_valid)
        self.assertEqual(mime, "image/webp")

    def test_reject_executable_or_fake_image(self):
        fake_bytes = b"MZ\x90\x00\x03\x00\x00\x00"  # Windows EXE
        is_valid, mime, err = validate_image_upload(fake_bytes, "malware.exe")
        self.assertFalse(is_valid)
        self.assertIn("Unsupported", err)

    def test_reject_empty_image(self):
        is_valid, mime, err = validate_image_upload(b"", "empty.png")
        self.assertFalse(is_valid)
        self.assertIn("empty", err)


class TestScoringAndCorrelation(unittest.TestCase):
    """Tests for evidence correlation and transparent risk scoring."""

    def test_score_calculation_and_cap(self):
        findings = [
            Finding(
                id="f1",
                title="Critical Credential Request",
                severity="critical",
                category="text",
                source_type="deterministic_check",
                evidence=["evidence 1"],
                explanation="expl",
                recommendation="rec",
                score_contribution=30,
            ),
            Finding(
                id="f2",
                title="Punycode Homograph",
                severity="high",
                category="url",
                source_type="deterministic_check",
                evidence=["evidence 2"],
                explanation="expl",
                recommendation="rec",
                score_contribution=25,
            ),
            Finding(
                id="f3",
                title="Host Exploit",
                severity="critical",
                category="logs",
                source_type="deterministic_check",
                evidence=["evidence 3"],
                explanation="expl",
                recommendation="rec",
                score_contribution=30,
            ),
            Finding(
                id="f4",
                title="Additional Flag",
                severity="high",
                category="url",
                source_type="deterministic_check",
                evidence=["evidence 4"],
                explanation="expl",
                recommendation="rec",
                score_contribution=30,
            ),
        ]
        risk, summary, final_findings, recs = correlate_and_score(
            findings=findings,
            has_url=True,
            has_text=True,
            has_image=False,
            has_logs=True,
            extracted_urls=[]
        )
        # Score capped at 100
        self.assertEqual(risk.score, 100)
        self.assertEqual(risk.label, "Very high concern")
        self.assertTrue(len(recs) > 0)

    def test_compound_threat_correlation(self):
        findings = [
            Finding(
                id="t1",
                title="Urgent Language",
                severity="high",
                category="text",
                source_type="deterministic_check",
                evidence=["evidence"],
                explanation="expl",
                recommendation="rec",
                score_contribution=20,
            ),
            Finding(
                id="u1",
                title="Punycode Link",
                severity="high",
                category="url",
                source_type="deterministic_check",
                evidence=["evidence"],
                explanation="expl",
                recommendation="rec",
                score_contribution=25,
            )
        ]
        risk, summary, final_findings, recs = correlate_and_score(
            findings=findings,
            has_url=True,
            has_text=True,
            has_image=False,
            has_logs=False,
            extracted_urls=[]
        )
        compound = [f for f in final_findings if f.category == "correlation"]
        self.assertTrue(len(compound) > 0)
        self.assertEqual(compound[0].severity, "critical")

    def test_deduplicate_findings(self):
        f1 = Finding(
            id="1", title="Non-HTTPS", severity="low", category="url",
            source_type="deterministic_check", evidence=["ev1"], explanation="x", recommendation="r"
        )
        f2 = Finding(
            id="2", title="Non-HTTPS", severity="low", category="url",
            source_type="deterministic_check", evidence=["ev2"], explanation="x", recommendation="r"
        )
        deduped = deduplicate_findings([f1, f2])
        self.assertEqual(len(deduped), 1)


class TestAdditionalEdgeCases(unittest.TestCase):
    """Additional edge cases for robustness."""

    def test_ipv6_host_detection(self):
        findings = analyze_static_url("http://[2001:db8::1]/login")
        ip_findings = [f for f in findings if "IP Address Host" in f.title]
        self.assertTrue(len(ip_findings) > 0)
        self.assertEqual(ip_findings[0].severity, "high")

    def test_multiple_brands_impersonation(self):
        for brand in ["microsoft", "netflix", "amazon", "chase"]:
            url = f"https://{brand}-security-verification-portal.com"
            findings = analyze_static_url(url)
            brand_findings = [f for f in findings if "Brand Impersonation" in f.title]
            self.assertTrue(len(brand_findings) > 0, f"Expected brand detection for {brand}")

    def test_log_directory_traversal(self):
        logs = 'GET /view?page=../../../../etc/passwd HTTP/1.1 200'
        findings = analyze_security_logs(logs)
        trav_findings = [f for f in findings if "Traversal" in f.title]
        self.assertTrue(len(trav_findings) > 0)

    def test_unconfigured_provider(self):
        from app import UnconfiguredGemmaProvider
        import asyncio
        p = UnconfiguredGemmaProvider()
        health = asyncio.run(p.health_check())
        self.assertEqual(health["status"], "not_configured")
        self.assertFalse(health["connected"])


class TestDemoGemmaProvider(unittest.IsolatedAsyncioTestCase):

    """Tests for the Gemma 4 transparent demo provider."""

    async def test_demo_health_check(self):
        provider = DemoGemma4Provider("google/gemma-4-E4B-it")
        health = await provider.health_check()
        self.assertEqual(health["status"], "demo")
        self.assertTrue(health["connected"])

    async def test_demo_text_labeled(self):
        provider = DemoGemma4Provider()
        findings = await provider.analyze_text("URGENT: Verify password immediately", {})
        self.assertTrue(len(findings) > 0)
        self.assertIn("Demo Mode", findings[0].title)
        self.assertEqual(findings[0].source_type, "ai_interpretation")


class TestApiEndpoints(unittest.TestCase):
    """End-to-end integration tests for FastAPI HTTP routes."""

    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        from app import app
        cls.client = TestClient(app)

    def test_get_root_serves_html(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("text/html", response.headers.get("content-type", ""))
        self.assertIn("CyberSage AI", response.text)
        self.assertIn("Content-Security-Policy", response.headers)

    def test_get_health(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data.get("status"), "healthy")
        self.assertEqual(data.get("ai_provider"), "demo")
        self.assertEqual(data.get("ai_status"), "demo")
        self.assertNotIn("api_key", response.text.lower())
        self.assertNotIn("secret", response.text.lower())

    def test_empty_investigation_rejected(self):
        response = self.client.post("/api/investigations", data={})
        self.assertEqual(response.status_code, 400)
        self.assertIn("At least one evidence source", response.json().get("detail", ""))

    def test_url_only_investigation(self):
        response = self.client.post("/api/investigations", data={"url": "https://bit.ly/3xSuspicious"})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["id"].startswith("inv_"))
        self.assertIn("risk", data)
        self.assertTrue(data["risk"]["score"] > 0)
        self.assertTrue(len(data["findings"]) > 0)
        self.assertTrue(len(data["recommendations"]) > 0)

    def test_text_only_investigation(self):
        response = self.client.post("/api/investigations", data={
            "text": "URGENT: Verify your password and 2FA code immediately within 24 hours."
        })
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["risk"]["label"], "High concern")
        self.assertTrue(data["risk"]["score"] >= 50)

    def test_valid_image_upload_investigation(self):
        png_content = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR" + b"\x00" * 32
        response = self.client.post(
            "/api/investigations",
            data={"title": "Screenshot Inspection Test"},
            files={"image": ("screenshot.png", png_content, "image/png")}
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["evidence_overview"]["image"]["provided"])
        self.assertEqual(data["evidence_overview"]["image"]["mime_type"], "image/png")

    def test_corrupt_image_upload_rejected(self):
        bad_content = b"MZ\x90\x00NOT_AN_IMAGE"
        response = self.client.post(
            "/api/investigations",
            files={"image": ("test.exe", bad_content, "application/octet-stream")}
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("Image upload validation failed", response.json().get("detail", ""))

    def test_full_multimodal_investigation(self):
        png_content = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR" + b"\x00" * 32
        response = self.client.post(
            "/api/investigations",
            data={
                "title": "Full Multimodal Incident Triage",
                "url": "http://paypal-security-update.com/login",
                "text": "URGENT: Immediate verification needed. Enter credentials now.",
                "logs": "Failed password for admin 10.0.0.1\nFailed password for admin 10.0.0.1\nFailed password for admin 10.0.0.1"
            },
            files={"image": ("fake_login.png", png_content, "image/png")}
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "completed")
        self.assertEqual(data["risk"]["label"], "Very high concern")
        # Check that multiple categories are present in findings
        categories = {f["category"] for f in data["findings"]}
        self.assertTrue({"url", "text", "logs"}.issubset(categories))


if __name__ == "__main__":
    unittest.main()

